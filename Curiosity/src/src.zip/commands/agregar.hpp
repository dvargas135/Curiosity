#ifndef AGREGAR_G
#define AGREGAR_G

#include "../classes/system.h"
#include <string>

void agregar_movimiento(std::string, std::string, std::string, System&);
void agregar_analisis(std::string, std::string, std::string, System&);
void agregar_elemento(std::string, std::string, std::string, std::string, std::string, System&);

#endif