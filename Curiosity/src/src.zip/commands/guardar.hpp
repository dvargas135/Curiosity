#ifndef GUARDAR_H
#define GUARDAR_H

#include "../classes/system.h"
#include <string>

void guardar(std::string, std::string, System&);

#endif