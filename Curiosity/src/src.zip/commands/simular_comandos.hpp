#ifndef SIMULAR_COMANDOS_H
#define SIMULAR_COMANDOS_H

#include "../classes/system.hpp"
#include <string>

void simular_comandos(std::string, std::string, std::string, System&);

#endif