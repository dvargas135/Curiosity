#ifndef AYUDA_H
#define AYUDA_H

#include <map>
#include <string>

void ayuda(std::map<std::string, int>, std::string);

#endif