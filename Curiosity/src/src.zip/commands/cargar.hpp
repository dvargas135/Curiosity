#ifndef CARGAR_H
#define CARGAR_H

#include <string>
#include "../classes/system.h"

void cargar_comandos(std::string, System&);
void cargar_elementos(std::string, System&);

#endif